<?php

namespace PaySystem\Exceptions;

class LanguageHelperException extends \Exception {
    
}
