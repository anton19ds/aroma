<?php

namespace PaySystem\Exceptions;

class MerchantReceiptHelperException extends \Exception {
    
}

